clc; %clearing console

x = -5:0.001:5;
y = 3*x + 10;
plot(x, y);