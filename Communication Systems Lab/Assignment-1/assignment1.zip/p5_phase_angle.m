clc; %clearing console

z = 3 + 4i;
theta = angle(z);

disp("Phase angle in radians: ");
disp(theta);

disp("Phase angle in degrees: ");
disp(rad2deg(theta));